package com.example.incr_decr_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int count = 0;
    private Button iButton, dButton;
    private TextView clicksCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iButton = findViewById(R.id.iButton);
        dButton = findViewById(R.id.dButton);
        clicksCount = findViewById(R.id.clicksCount);

        iButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count++;
                clicksCount.setText(count +" Clicks !");
            }
        });

        dButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count--;
                clicksCount.setText(count +" Clicks !");
            }
        });
    }
}
